    <hr>
    <div class="row">
        <div class="col-sm-12">
            <footer>
                <p>© Copyright 2017 Pluck</p>
            </footer>
        </div>
    </div>
</div>
</body>
</html>                                     


